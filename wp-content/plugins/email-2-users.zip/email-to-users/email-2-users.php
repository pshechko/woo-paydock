<?php
/*
  Plugin Name: Email To Users
  Plugin URI: https://houstonapps.co/
  Description: Adds a selected articles widget
  Version: 1
  Author: pshechko
  Author URI: https://houstonapps.co/
 */

define("EMAIL2USERSURI", plugins_url('', __FILE__));
define("EMAIL2USERSDIR", plugin_dir_path(__FILE__));

add_action('admin_menu', 'add_itc_pages');

function send_email_to_all_users($text, $subject, $user_query = false) { //this is function you'r looking for
    if (!is_a($user_query, 'WP_User_Query')) {
        $args = [
            'number' => -1
        ];
        $user_query = new WP_User_Query($args);
    }
    $allusers = $user_query->get_results();
    foreach ($allusers as $i => $user) {
        $allusers[$i]->sent = wp_mail($user->data->user_email, $subject, $text);
    }

    return $allusers;
}

// Next is just an example how does the query works

function add_itc_pages() { //add settings subpage
    add_submenu_page('options-general.php', 'Email to users', 'Email to users', 'manage_options', 'email-2-users', 'email_2_users_cb');
}

function email_2_users_cb() { //settings subpage cb
    $args = [
        'number' => -1
    ];

    $user_query = new WP_User_Query($args);
    $allusers = $user_query->get_results();

    if (isset($_POST['message'])) {
        foreach ($allusers as $i => $user) {
            $allusers[$i]->sent = wp_mail($user->data->user_email, "Some subject", $_POST['message']);
        }
        echo "<h2>Emails have been sent successfully</h2>";
    }
    ?>
    <form action="options-general.php?page=email-2-users" method="post">

        <textarea style="min-width: 400px;" name="message" placeholder="Enter your message"><?php if (isset($_POST['message'])) echo htmlspecialchars($_POST['message']); ?></textarea>

        <p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Submit"></p>

        <div class="table">
            <div>
                <div>
                    Number
                </div>   
                <div>
                    User
                </div>  
                <div>
                    Email
                </div>   
                <?php if (isset($_POST['message'])): ?>
                    <div>
                        Status
                    </div>   
                <?php endif; ?>
            </div>
            <?php
            foreach ($allusers as $i => $user):
                ?>
                <div class='single-user'>
                    <div>
                        <h3>
                            <?php echo ($i + 1); ?>
                        </h3>
                    </div>
                    <div>
                        <h3>
                            <?php echo $user->data->user_nicename; ?>
                        </h3>
                    </div>
                    <div>
                        <h3>
                            <?php echo "<a href='mailto:{$user->data->user_email}'>{$user->data->user_email}</a>"; ?>
                        </h3>
                    </div>
                    <?php if (isset($_POST['message'])): ?>
                        <div>
                            <h3>
                                <?php echo $user->sent ? " <span style='color: green'>success</span>" : " <span style='color: red'>failure</span>"; ?>
                            </h3>
                        </div>
                    <?php endif; ?>
                </div>
                <?php
            endforeach;
            ?>
        </div>
    </form>
    <style>
        .table{
            display: table;
            border-spacing: 10px;
        }
        .table>div{
            display: table-row;
        }
        .table>div>div{
            display: table-cell;
        }
    </style>
    <?php
}
