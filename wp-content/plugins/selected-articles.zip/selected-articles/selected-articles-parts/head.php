<div class="c-articles-block">
    <div class="c-articles-head">
        <h2> 
            Selected articles 
        </h2>
    </div>