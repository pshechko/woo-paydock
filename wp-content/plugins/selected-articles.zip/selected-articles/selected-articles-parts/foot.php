<?php 
/*
 * $args = [
 *      'redirect' => Read more link  
 * ]
 */ 
?>
<?php if (!empty($args['url'])): ?>
    <div class="c-articles-foot"> 
        <a href="<?= $args['url'] ?>" class="blue-btn"> read all </a> 
    </div>
<?php endif ?>
</div>
