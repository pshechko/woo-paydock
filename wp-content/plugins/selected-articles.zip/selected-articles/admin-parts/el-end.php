<?php if (!empty($args['element'])): ?>
    </<?= $args['element'] ?>>
<?php endif; ?>