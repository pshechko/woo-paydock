<div>
    <label for="<?= $args['id'] ?>">
        <?= __('Search','woothemes').":" ?>
    </label>

    <input class="widefat"
           id="<?= $args['id'] ?>"
           placeholder="<?php _e("Start typing to search for a specific article", "woothemes"); ?> " />
</div>

<br />
